# Task 1 Spring independent review

사양 판정: **수정 필요**. 코드 품질 판정: **수정 필요**. 금액·정수·기본값·null·enum·unknown-field 처리는 검토한 경계에서 적절하지만, 두 언어가 같은 JSON을 해석한다는 완료 조건을 깨는 Unicode 문자열 차이가 두 건 있다.

## 범위와 검증

- 대상: Spring `9d411060e10c4fbb283e8acdc9023966be8e53f9..1c9b183ef7e2569697a4ba3b7d2ab4d78c6064d5`. 검토 시 HEAD가 대상 SHA와 일치했다.
- 요구사항: `task-1-brief.md`, 구현 보고서: `task-1-report.md`. 신규 DTO·문서·테스트만 검토했다. Python `app/schemas/agent.py`는 계약 호환성을 대조하기 위해 읽었다.
- 변경 목록은 신규 DTO 16개, 테스트 1개 및 계약 문서/fixture다. global ObjectMapper, 기존 endpoint/DTO, domain/service/repository, bplus 변경은 없다. 예약·결제·실시간 좌석 기능을 구현하거나 검증했다고 주장하지 않는다.
- 저장된 Spring XML 결과: **82 tests / 0 failures / 0 errors / 0 skipped**, 그중 `AgentContractTest` 6개. 전체 테스트를 다시 실행하지 않았다.
- 계약 문서 32개는 Python/Spring 간 byte-identical이며 JSON 31개는 Spring test resources 복사본과도 동일하다.
- 추가 검증은 기존 compiled DTO, Jackson 2.17.1, Hibernate Validator 8.0.1과 Python 모델을 이용한 아래 문자열 경계 probe만 수행했다. 제품 코드 수정은 없다.

## Findings

### Critical

없음.

### Important

**R1 — Unicode 공백을 두 언어가 다르게 정규화하고 검증한다.**

- Spring 근거: `backend/src/main/java/com/janginharou/domain/ai/dto/agent/WireValues.java:44`, `AgentRequest.java:14`, `CatalogSearchRequest.java:16`.
- Python 근거: `backend-python/app/schemas/agent.py:25`, `:103`, `:109`.
- 재현: `{"query":"\u00a0"}`는 Spring deserialization 및 Bean Validation을 통과한다. Python은 공백 제거 후 빈 문자열로 판정하여 거부한다. `{"query":"\u00a0한지\u00a0"}`는 Spring에서 padding을 유지하지만 Python은 `한지`로 정규화한다.
- 발생 경로: Java `String.strip()`와 Hibernate `@NotBlank`가 사용하는 Java whitespace 판정은 U+00A0를 공백으로 처리하지 않는다. Python/Pydantic의 string whitespace stripping은 이를 제거한다. 동일한 `StringValue`와 `@NotBlank` 조합을 쓰는 queryTerms·근거 문자열에도 같은 정적 차이가 있다.
- 영향: 공백만 있는 요청/검색어 거부 및 trim 후 1~50자라는 명시 계약이 깨진다. 외부 Spring과 내부 Python의 입력 허용 여부 및 문자열 값이 달라진다. 현재 공유 실패 예제는 ASCII space만 다뤄 이를 막지 못한다.
- 판정: **수용 / 수정 필요**. 두 언어가 공유하는 Unicode 공백 규칙으로 Spring 정규화를 맞추고 U+00A0 빈 값·padding 및 queryTerms 회귀 사례를 공유 예제에 추가한다.

**R2 — Java UTF-16 길이로 Python의 문자 수 제한을 적용한다.**

- Spring 근거: `backend/src/main/java/com/janginharou/domain/ai/dto/agent/AgentRequest.java:14`, `CatalogSearchRequest.java:16`, `CultureSearchRequest.java:8`, `CatalogExperienceResponse.java:14`, `CultureDocument.java:13`.
- Python 근거: `backend-python/app/schemas/agent.py:89`, `:103`, `:117`, `:134`, `:143`.
- 재현: query에 `😀` 300개를 넣으면 Python은 300자로 보고 허용하고 Spring은 UTF-16 600개 단위로 보고 거부한다. queryTerms의 `😀` 30개도 Python은 허용하지만 Spring은 60으로 계산하여 거부한다. 500자 경계의 일반 한국어 query에 emoji 한 글자만 포함해도 같은 문제가 발생한다.
- 발생 경로: Hibernate `@Size`는 Java `CharSequence.length()`를 사용한다. supplementary Unicode 문자는 Java에서 두 단위지만 Python/Pydantic은 한 문자로 센다. excerpt의 1200자 제한도 같은 방식으로 달라진다.
- 영향: 명시 범위 안의 동일한 유효 JSON을 Spring이 거부하며, Python이 생성한 범위 내 excerpt도 Spring에서는 검증 실패할 수 있다. 기존 예제는 BMP 문자만 써 이 경계를 확인하지 않는다.
- 판정: **수용 / 수정 필요**. JSON Schema/Python과 같은 Unicode code-point 기준으로 Spring 길이를 검증하고 query/queryTerms/excerpt 경계를 공유 예제로 고정한다.

### Minor

이번 Spring 리뷰에서 별도 확정 지적 없음. 금액 JSON Schema의 trailing-LF 이슈는 부모 리뷰의 별도 원장에 있으며 이 리뷰의 중복 지적으로 만들지 않았다.

## 적절한 구현과 반증

- 금액 입력은 raw numeric token에서 BigDecimal을 직접 읽고 `toPlainString()`으로 문자열 출력한다. 부호/문자열 지수/coercion 거부, 큰 금액의 정확성, 유효 소수 2자리 경계는 공유 예제와 테스트에서 확인된다. float 변환은 없다.
- DTO에 한정한 deserializer와 `StrictContract`는 기존 global mapper/API를 바꾸지 않는다. request/search/constraints/draft의 초기값과 명시 null 거부는 Python 계약과 일치한다. nullable-but-required regionCode/category도 선언되어 있다.
- response의 status/추천 ID 순서·중복·unsupportedConstraints 일관성 검증과 draft의 문화 문서 근거 요구가 구현되어 있다. 자연어 충돌 감지 자체가 아직 없다는 한계는 문서가 명시한다.
- 반증한 후보: `@JsonIgnore` 검증 helper 속성 `pricePrecisionValid`가 unknown-field 거부를 우회할 수 있다는 가설은 focused probe에서 거부됨을 확인하여 **기각**했다. 임의 unknown `extra`도 거부한다.
- 현재 6개 테스트는 여러 공유 fixture를 반복 검증하므로 개수 자체를 품질 결함으로 보지 않는다. 다만 Unicode 입력의 별도 경계가 빠져 있다.

## ⚠ 직접 확인하지 않은 주장과 완료 조건

- 구현 이전 TDD 실패 이력 및 과거 Gradle 실행/guard 결과는 구현 보고서에 있으나 이 리뷰에서 과거 로그를 재생하거나 독립 재현하지 않았다. 저장된 최종 XML의 82개 통과와 파일 동일성은 직접 확인했다.
- 실제 HTTP route는 범위 밖이므로 향후 route의 `@Valid`, raw-body Decimal 처리, 인증, ApiResponse 조립 및 catalog 검색 동작은 이 리뷰의 통과 주장에 포함하지 않는다.
- 기존 legacy API가 diff에서 수정되지 않았고 저장된 전체 결과는 초록이다. 살아 있는 서비스/DB를 호출해 보존 동작을 별도 검증하지 않았다.
- R1/R2 수정 및 공유 문자열 경계 확인 후 Spring 사양/품질 판정을 갱신해야 한다. 그 전에는 Task 1의 양 언어 계약 동일성 완료 조건이 충족됐다고 선언할 수 없다.
