## Task 2: Spring 읽기 전용 catalog API

**Consumes:** Task 1의 Constraints/Catalog DTO. **Produces:** 두 내부 API와 fixture 호환 응답.

- [ ] service key 미설정 503·누락 401·불일치 403·정상 성공, 다른 경로의 권한에 영향이 없는지 먼저 테스트한다.
- [ ] `InternalAiCatalogService.search(request)`와 `getDetail(id, constraints)`를 구현한다. DB 트랜잭션은 각 호출의 짧은 readOnly 구간으로 제한한다.
- [ ] 필터를 limit 전에 적용한다. 상위 조건 불일치 항목이 다수 있어도 조건에 맞는 항목을 찾는 테스트를 작성한다.
- [ ] BigDecimal 비교, active=false, null address, 정원 부족, 여러 태그에 의한 중복, LIKE wildcard를 검증한다.
- [ ] 제목/태그 일치 점수 → ID 순서, 최대 10개, null 허용 필드를 고정한다.
- [ ] 내부 인증 필터를 지정 경로에만 적용한다. catalog 서비스가 AI 서비스를 호출하지 않는지 검증한다.
- [ ] DB 조회 timeout 2초와 connection acquisition timeout을 실험 환경에 적용한다. 각 조회를 끝내고 응답 DTO로 변환한 뒤 연결을 반환한다.

**Validation:** `./gradlew test --tests '*InternalAiCatalog*' --tests '*AiServiceKey*'`. 이 작업에서는 일정별 예약 가능 여부를 판단하지 않는다.

## 구현 범위와 계약

- Spring 저장소만 수정한다. Task 1의 `com.janginharou.domain.ai.dto.agent` DTO와 `docs/contracts/agent-v1` 계약을 재사용한다.
- Task 3 이후 모델/그래프/외부 agent endpoint는 이번에 만들지 않는다.
- POST `/internal/ai/experiences/search`: body={queryTerms, constraints, limit}; GET `/internal/ai/experiences/{id}`: query=regionCode/maxPriceKrw/headCount.
- ApiResponse(success,message,data,errorCode) envelope를 사용한다. detail 미존재/비활성/조건 불일치는 404, search 빈 결과는 200 data=[].
- X-AI-Service-Key 필터는 정확한 메서드/경로만 인증하고 ROLE_AI_SERVICE 권한을 설정한다. 키 미설정503/누락401/불일치403. 기존 JWT/공개 경로는 유지한다. 자동 servlet 필터 중복 등록은 방지한다.
- 가격은 Decimal 문자열, 인원 1~20, 지역 SEOUL/GYEONGGI/INCHEON/BUSAN/JEJU다. unknown fields는 신규 DTO에서 거부하고 글로벌 mapper를 변경하지 않는다.
- DB query timeout2초는 catalog query에만 적용한다. 기존 Hikari 글로벌 pool 설정은 변경하지 않는다.
- 최대10개, 기본5개. active/가격/정원/지역을 SQL limit 전에 강제한다. 조회 목록 전체를 메모리로 읽은 뒤 필터링하지 않는다.
- title/description/tags에서 하나 이상의 검색어 일치, 제목/태그 점수 후 ID 안정정렬. empty term 거부, `%`, `_`, 백슬래시는 LIKE literal 처리. 중복 태그로 행이 늘어나지 않도록 한다.
- 주소는 시·도 접두어로 정규화하고 미지원/빈 주소는 지역 필터 요청에서 제외한다. maxParticipants는 잔여 좌석이 아니다.
- 실제 JPA/H2 integration 테스트로 Decimal경계, 필터-before-limit, null주소, 중복태그, LIKE escaping과 정렬을 검증한다. PostgreSQL 전용 문법을 쓰면 로컬 PostgreSQL검증도 필요하다.
- service는 짧은 readOnly transaction 안에서 tags lazy access와 DTO 변환을 완료한다. AI서비스를 재호출하지 않는다.
- bplus 제외. 브랜치 feat/langgraph-catalog-contracts. JDK17=/private/tmp/janginharou-tools/jdk-17.0.20.1+1/Contents/Home, Gradle cache=/private/tmp/janginharou-gradle.


## HTTP 입력 검증 보완
- 신규 내부 API의 malformed JSON/unknown-field/타입 오류 및 부적합 GET constraints는 400 ApiResponse로 반환하도록 테스트한다. 기존 GlobalExceptionHandler generic catch가 JSON decoding 오류를 500으로 처리할 수 있으므로 신규 컨트롤러 범위로 제한한 advice/처리를 사용하고 기존 API 오류 동작은 바꾸지 않는다.
- config 설명/운영 runbook에 AI_SERVICE_KEY 환경변수와 기본 미설정503을 기록한다. 실제 비밀 키 파일/값은 커밋하지 않는다.
