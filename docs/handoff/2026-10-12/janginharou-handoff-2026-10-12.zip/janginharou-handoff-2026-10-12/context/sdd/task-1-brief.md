## Task 1: 계약·기준 응답·평가 데이터 고정

**Deliverable:** 두 저장소가 같은 agent JSON을 해석하고 기존 비교군과 실험 데이터를 식별할 수 있다.

- [ ] 신규 Pydantic/Java DTO 작성 전 요청 범위·enum·Decimal·충돌 조건 실패 테스트 작성.
- [ ] 기존 6개 smoke 질의를 culture dataset에 가져오고 총 20개로 확장한다: 정확명/자연어 표현/모호 질문/무관 질문 각각 5개.
- [ ] 추천 dataset 20개 작성: 정상/가격 경계/지역·인원 경계/무결과·비활성·모호 조건 각각 5개. 각 사례에 supported mode와 allowedIds, forbiddenIds, expectedStatus 기록.
- [ ] 합성 catalog 12개 구성: 지역 3종, 가격 경계값 50000/50000.01/49999.99, 정원 2/3/4, active/inactive, 빈 주소를 포함한다. ID는 fixture 전용 101~112.
- [ ] 문화 expected source는 고정된 실제 heritage snapshot의 ID를 사용한다. 사람이 모든 질의의 정답 문서를 확인하고 snapshot_hash에 기록한다.
- [ ] dataset에 dev/test 각 10개를 명시한다. 동일 질문의 표현 변형은 같은 split에 배정한다.
- [ ] 기존 endpoint의 대표 응답 JSON과 오류를 보존 테스트로 고정한다.

계약 테스트 예시(신규 모델 위치 확정):

```python
from decimal import Decimal
import pytest
from pydantic import ValidationError
from app.schemas.agent import AgentConstraints

def test_price_preserves_decimal_boundary():
    value = AgentConstraints(maxPriceKrw="50000.01", headCount=3)
    assert value.maxPriceKrw == Decimal("50000.01")

def test_head_count_rejects_zero():
    with pytest.raises(ValidationError):
        AgentConstraints(headCount=0)
```

**Validation:** `uv run pytest tests/agent/test_contracts.py -q`; Spring 신규 DTO validation tests. 완료 기준은 두 언어의 JSON 직렬화와 경계값 테스트 통과다.


## 공통 계약과 구현 범위
## 2. 신규 API와 데이터 계약

### 요청/응답

- Python 내부 API: `POST /api/v1/ai/agent/recommendations` — 기존 `X-Internal-Api-Key` 인증 재사용.
- Spring 외부 API: `POST /v1/ai/agent/recommendations` — 초기에는 인증된 사용자만 허용. 기존 추천 API의 공개 여부를 복사하지 않는다.
- Spring 도구 API: `POST /internal/ai/experiences/search`, `GET /internal/ai/experiences/{id}`.
- 내부 도구 API는 agent 전용 서비스 키 `X-AI-Service-Key`로 보호한다. JWT 없이 내부 인증 필터가 이 정확한 경로에만 인증 객체를 설정한다. 기존 JWT 인증과 다른 경로의 권한은 유지한다.
- FastAPI가 Spring의 외부 AI API를 재호출하지 않는다. 내부 catalog API는 Experience 조회 서비스에만 연결해 호출 순환을 막는다.

신규 요청 예시:

```json
{
  "query": "서울에서 부모님과 한지 체험을 하고 싶어요. 1인당 5만원 이하로요",
  "locale": "ko",
  "constraints": {"regionCode": "SEOUL", "maxPriceKrw": "50000", "headCount": 3}
}
```

- query: 1~500자; locale: v1은 ko만; headCount: 1~20; maxPriceKrw: 0 이상, 소수 2자리 이내 Decimal.
- 구조화 필드와 자연어 조건이 충돌하면 `clarification_required`로 종료한다. 명시 조건을 LLM이 넓히거나 삭제할 수 없다.
- 구조화 조건이 없으면 별도 모델 호출에서 typed intent를 추출한다. 모호한 예산 단위(총액/1인당)와 지역은 확인 질문으로 종료한다.
- v1 지역 코드: SEOUL/GYEONGGI/INCHEON/BUSAN/JEJU. 주소의 시·도 접두어와 매핑한다. 미지원 지역은 확인 질문, 주소가 없는 항목은 지역 제한 요청에서 제외한다.
- 날짜·주말·시간대·휠체어 접근·언어 지원 등 v1 미지원 조건은 `unsupportedConstraints`에 반환하고 확인 질문으로 종료한다. 충족했다고 안내하지 않는다.
- ‘부모님과’는 가족 관심 맥락으로 사용하며 고령자 적합성이 검증됐다는 사실로 변환하지 않는다.

Python 응답 계약:

```json
{
  "status": "completed",
  "answer": "조건에 맞는 한지 체험을 확인했습니다.",
  "recommendedExperienceIds": [101],
  "recommendations": [{"experienceId": 101, "reason": "한지 만들기 체험", "evidenceKeys": ["experience:101:title"]}],
  "sources": [],
  "appliedConstraints": {"regionCode": "SEOUL", "maxPriceKrw": "50000", "headCount": 3},
  "unsupportedConstraints": [],
  "limitations": ["일정별 잔여 좌석은 확인하지 않았습니다."],
  "requestId": "agent-demo-001"
}
```

- status는 `completed | no_match | clarification_required | degraded`.
- 기술 실패·예산 초과가 빈 추천 정상 성공으로 바뀌지 않는다. API 오류는 400/401/403/502/503/504로 분리하고 평가기에 그대로 기록한다.
- 모델의 draft에는 숫자·ID·가격·주소를 임의 자유 서술하지 않고 `experienceId`, `reason`, `evidenceKeys`, 문화 답변/claim 단위를 구조화하여 받는다.
- 가격·지역·정원 표시는 검증한 catalog DTO에서 서버가 렌더링한다. culture claim은 retrieved document ID를 필수로 참조한다. 구조 검증과 별도로 사실성 평가는 오프라인 judge/human으로 수행한다.
- Spring 외부 응답은 기존 `ApiResponse` envelope 안에 신규 Agent 응답 DTO를 넣고 최종 조회한 제목·가격·이미지를 조립한다.

### 도구 계약

| 도구 | 입력 | 출력 | 검증 |
|---|---|---|---|
| search_culture_documents | query 1~500자 | 최대 5개 문서: documentId/heritageId/title/source/category/contentExcerpt | 기존 검색 결과를 직렬화. excerpt 문서당 1200자 |
| search_experiences | queryTerms 1~5개(각 1~50자), limit 1~10 | catalog items: id/title/descriptionExcerpt/tags/priceKrw/maxParticipants/regionCode/isActive | 지역·가격·인원은 State의 고정 조건을 서버가 주입. 모델 인자로 받지 않음 |
| get_experience_details | experienceId | 동일 DTO와 상세 설명 | active 여부와 고정 조건을 다시 검증. 비활성/없는 ID는 not_found |

Spring search는 active + 가격 + 인원 + 지역 필터를 **limit보다 먼저** 적용한다. 검색어 중 하나 이상이 title/description/tags에 일치하는 항목을 찾고 태그/제목 일치 점수 후 id로 안정 정렬한다. 빈 검색어는 전체 목록 조회로 처리하지 않는다. 검색어 `%`, `_`는 LIKE literal escape한다. v1 추천 검색은 lexical catalog 검색이라는 점을 평가 보고서에 명시한다.


## 범위 보정
이번 요청은 Task 1/2만 구현합니다. 실제 문화 snapshot은 현재 없습니다. 문화 seed는 합성 fixture/provenance를 명시하고 실제 품질 평가로 주장하지 않습니다. 실제 snapshot 수집은 Task 6 전입니다.
Spring internal search body는 {queryTerms, constraints, limit}; detail은 regionCode/maxPriceKrw/headCount query params를 받습니다. Catalog 응답은 기존 ApiResponse envelope(data 배열 또는 객체)에 담깁니다. headCount의 constraints 기본값은 1입니다. culture 요청은 인원 조건을 사용하지 않습니다. 모든 JSON unknown fields를 거부하고 숫자 금액은 허용하되 문자열 decimal로 직렬화합니다.

## Global Constraints

- 범위는 `fingertip-app/backend-python`과 `fingertip-app/backend`이다. bplus는 제외한다.
- 조사 기준: Python `develop` = `cf9cd219b8baabcbc8079dbe6c30cdc04e5e126e`; Spring `develop` = `58b712a69277c2c0e3887f51bc20c861a6706f01`.
- 구현 시작 시 두 SHA와 로컬 변경을 다시 기록한다. 기준이 바뀌면 아래 파일·계약을 재대조한다.
- 새 브랜치 이름에는 `codex/`를 붙이지 않는다. 후보: `feat/langgraph-agent-evaluation`.
- 기존 `/api/v1/ai/explain`, `/api/v1/ai/recommendations`, Spring `/v1/ai/recommendations`의 요청·응답 계약을 유지한다.
- 첫 버전은 단일 에이전트, 요청 단위 상태, 한국어 응답, 읽기 전용 도구 3개로 구현한다.
- 예약 실행·결제·일정별 잔여 좌석 조회는 범위 밖이다. `maxParticipants`는 프로그램 정원이고 예약 가능한 좌석 수가 아니다.
- 멀티턴 영구 저장·SSE·멀티에이전트·클라우드 평가 업로드는 후속 범위다. 첫 버전에서 작동한다고 주장하지 않는다.
- 모델은 `AGENT_MODEL`로 기존 `OPENAI_GENERATION_MODEL`과 같은 값부터 시작한다. 도구 호출·구조화 출력 지원 여부를 첫 실험에서 확인한다.
- 도구 호출은 순차 실행한다. SQLAlchemy Session을 LangGraph State 또는 병렬 노드에 넣지 않는다.
- 재검색/답변 수정은 합산 최대 2회, 도구 호출 최대 6회, 모델 호출 최대 6회, 그래프 recursion_limit 32, 전체 실행 목표 상한 45초다. 한도를 넘으면 종료한다.
- 공급자 자동 재시도는 0으로 시작해 호출 횟수·시간을 정확히 측정한다. 네트워크 호출별 timeout은 남은 요청 예산과 설정값 중 작은 값이다. 개별 제한의 누적으로 전체 예산을 넘기지 않는다.
- 가격은 KRW 1인당 금액으로 취급한다. Spring BigDecimal과 Python Decimal/문자열로 전송하고 float 변환을 피한다.
- Python 서비스 도메인 테이블의 쓰기·새 마이그레이션은 추가하지 않는다.
- 기존 개인정보 마스킹을 도구 인자·모델 입력·평가 출력에 적용한다. API 키·원문 사용자 대화는 실행 추적에 기록하지 않는다.
- 이번 계획 작성에서는 애플리케이션 코드, 원격 저장소, 환경설정을 수정하지 않았다.


## Java/Python 계약 세부
CatalogSearchRequest: queryTerms 1~5개 trim 후 각각 1~50자(공백만 거부), constraints default headCount=1, limit default5 및1~10. CatalogExperienceResponse는 id/title/descriptionExcerpt/tags/priceKrw/maxParticipants/regionCode/isActive 필드를 가지며 가격은 문자열 Decimal로 직렬화합니다. Spring ApiResponse<T>는 success/message/data/errorCode envelope입니다. 새 DTO에는 글로벌 object mapper를 변경하지 않고 unknown fields 거부를 구현하세요. v1 지역 enum SEOUL/GYEONGGI/INCHEON/BUSAN/JEJU; locale ko. AgentStatus 네 값(completed/no_match/clarification_required/degraded)은 JSON lowercase underscore로 맞춥니다. 실제 agent endpoint/graph는 이번에 추가하지 않습니다.
