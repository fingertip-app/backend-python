# Task 1 implementation report

## Scope and baseline

Task 1 only: new contracts, strict shared examples, synthetic offline evaluation data and preservation tests. No endpoint/agent graph/catalog service/filter/repository/domain migration changes. Python initial HEAD 335720e63050765575da679094663bbc94925a84 and Spring initial HEAD 9d411060e10c4fbb283e8acdc9023966be8e53f9 were clean on feat/langgraph-catalog-contracts. Parent baseline65 Python / 76 Spring tests. Actual heritage snapshot remains unavailable; no real quality or human fact-checking claim is made.

## Python commits and corrective review evidence

- Initial contracts/seed commit: a8bd0ab78f21eeb34845f2e15166feaf4d06af43. Guard capture 38/index/head passed. Baseline plus new tests:112 passed (`.venv/bin/python -m pytest tests -q`).
- Corrective commit: 8c22d88ced5d528938e6d0df7ca61c541ec92f75. Accepted review R1/R2 were reproduced before fixes. Focused new tests:6 failed / 44 passed, showing numeric9007199254740993.01 rounded to9007199254740994, numeric50000.000000000001 accepted, string negative/+1/exponent inconsistencies, missing numeric multipleOf. Signed numeric zero then independently failed1 failed / 50 passed before normalization to0.00.
- Corrected `app/schemas/agent.py`: exported `parse_contract_json(raw)` uses json.loads(parse_float=Decimal); all StrictContract.model_validate_json entry points reuse it. Invalid/nonfinite JSON is rejected. Future FastAPI agent route must pass raw request.body() bytes through this function; the standard JSON float parser cannot recover precision. No current HTTP route was added.
- `app/evaluation/dataset.py` uses the same entry point for both dataset JSON and referenced corpus JSON.
- Validation schema accepts exact nonnegative numeric cents (minimum0/multipleOf0.01); string grammar is unsigned ordinary decimal notation, up to two effective fractional digits (further trailing0allowed). String exponent/+sign/nonfinite rejected; numeric exponent allowed. Signed numeric zero normalized to unsigned output. No monetary upper bound added.
- `jsonschema` was added to dev extras and uv.lock, so checked-in schemas are exercised through Draft202012Validator with Decimal numeric inputs.
- Tests: `tests/agent/test_contracts.py` verifies raw numeric tokens, shared valid/invalid examples, schema/runtime string parity, numeric schema cents, fields/enums/nulls/unknowns/coercion/status, and nine wire example roundtrips. `tests/agent/test_dataset.py` verifies seed count/splits/smoke queries/catalog boundaries/hash/source references/group leaks. `tests/agent/test_legacy_snapshots.py` pins existing explain/recommendation JSON/auth/fallback and keeps legacy wider request limits.
- Final Python command: `.venv/bin/python -m pytest tests -q`; output `128 passed in 1.82s` (65 baseline + 63 Task 1). Corrective guard capture 19/index/head passed with nonempty checks `[["uv","run","--extra","dev","pytest","tests","-q"]]`.

Initial TDD evidence: missing module collection errors were followed by unimplemented schema/loader scaffolds and a real red run39 failed / 1 passed. Decimal conversion, invalid constraint bounds, scope/unknown fields, search blank/ranges and normalization all failed before implementation. Initial 40 focused tests then passed; preservation and shared-invalid tests characterize existing behavior and were added without changing it.

Bare `pytest -q` also collects historical scripts/test_combined_score.py, test_lexical_score.py, test_lexical_score2.py and test_rag_search.py; those fail during collection without a live DB/DATABASE_URL. The defined offline regression suite is pytest tests. Historical scripts and baseline tests were not edited.

## Spring

Commit: 1c9b183ef7e2569697a4ba3b7d2ab4d78c6064d5. Guard capture 80/index/head passed with nonempty checks [["env","JAVA_HOME=/private/tmp/janginharou-tools/jdk-17.0.20.1+1/Contents/Home","GRADLE_USER_HOME=/private/tmp/janginharou-gradle","./gradlew","test","--no-daemon"]].

TDD:AgentContractTest compiled and ran before DTOs;5 tests failed on missing contract assertions. Added detail/culture/draft/rawdecimal examples then2 tests failed (missing DTO and over-permissive exponent/signed decimal strings). These were fixed with scoped DTO additions and decimal deserializer. During initial green work, record creator @JsonSetter(nulls=FAIL) also rejected missing optional defaults, so request/constraints/search are POJOs with initialized fields; explicit null still rejects. Existing DTOs/global mapper were not changed.

Final command:env JAVA_HOME=/private/tmp/janginharou-tools/jdk-17.0.20.1+1/Contents/Home GRADLE_USER_HOME=/private/tmp/janginharou-gradle ./gradlew test --no-daemon. BUILD SUCCESSFUL in 48s; XML totals82 tests/0failures/0errors (76 baseline + 6 new). Gradle needed permission for local JVM socket, then succeeded; existing Gradle9deprecation and JVM CDS warnings remain.

AgentContractTest runs against an ObjectMapper configured to ignore unknown fields, confirming every new DTO's local StrictContract rejection. Scoped deserializers reject int/long floats and string integer coercion, non-string text, non-boolean active values and unsupported price string forms. BigDecimal numeric parsing uses the original token and writes toPlainString. Bean validation verifies ranges, enums, nested request constraints, two effective decimal places, status/ID consistency and unsupported-condition clarification. Existing controller/client/service tests preserve Spring legacy paths and envelope/error behavior.

AgentConstraints/AgentRequest/CatalogSearchRequest/AgentDraft expose conventional get... accessors. Response DTOs and culture tool DTOs are records. Task2detail should use CatalogExperienceDetailsResponse (same catalog fields plus description). Catalog nullable regionCode and culture nullable category are required wire fields, so missing/null are distinguished with requiredJsonProperty on records.

All 32 files under docs/contracts/agent-v1 are byte-identical between repos. All 31 JSON files are also byte-identical to src/test/resources/contracts/agent-v1 copies. Compared contents explicitly before commit; shared valid examples cover request/completed/clarification/search/catalog/detail/culture-search/culture-documents/draft. Shared invalid-examples.json and decimal-wire-examples.json cover boundary/null/unknown/coercion/exactprice inputs in both languages.

## Synthetic data provenance

culture.json and recommendation.json each contain 20 cases, four categories with 5 each and dev 10 / test 10. All 6 existing culture smoke queries retained. Culture exact/natural paraphrases share group/split. Catalog IDs101–112 only:SEOUL/GYEONGGI/BUSAN, active/inactive, empty address/nullregion, 50000/50000.01/49999.99 and0price, capacities2/3/4. Culture corpus contains 5 synthetic documents with synthetic IDs and source URI. Corpus raw bytes SHA-256 is pinned in each dataset. All provenance.kind=synthetic and humanReviewed=false. Expected recommendation IDs were independently derived from fixture rows; no search implementation generated expected sets. Facts/actual heritage IDs/model quality/human verification are not claimed. Actual heritage snapshot collection and review remain prerequisites before Task6 real evaluation.

## Publication and limits

No push or PR creation. Parent owns clean-checkout validation and publication; capture/index/head only were requested for subtask commits. Provider/model/live DB calls were not run. Natural-language extraction/conflict handling, server-rendered factual claims and actual agent evaluation remain future tasks. Localeko and regional codes are v1 limits; unsupported schedule/accessibility conditions require clarification. maxParticipants is program capacity, not live availability. v1 recommendation search is lexical catalog search.

## Python complete file inventory (45 files)

Repository: /Users/yj/Desktop/Projects/janginharou/backend-python

- app/evaluation/__init__.py
- app/evaluation/dataset.py
- app/schemas/agent.py
- docs/contracts/agent-v1/AgentDraft.serialization.schema.json
- docs/contracts/agent-v1/AgentDraft.validation.schema.json
- docs/contracts/agent-v1/AgentRequest.serialization.schema.json
- docs/contracts/agent-v1/AgentRequest.validation.schema.json
- docs/contracts/agent-v1/AgentResponse.serialization.schema.json
- docs/contracts/agent-v1/AgentResponse.validation.schema.json
- docs/contracts/agent-v1/CatalogExperienceDetailsResponse.serialization.schema.json
- docs/contracts/agent-v1/CatalogExperienceDetailsResponse.validation.schema.json
- docs/contracts/agent-v1/CatalogExperienceResponse.serialization.schema.json
- docs/contracts/agent-v1/CatalogExperienceResponse.validation.schema.json
- docs/contracts/agent-v1/CatalogSearchRequest.serialization.schema.json
- docs/contracts/agent-v1/CatalogSearchRequest.validation.schema.json
- docs/contracts/agent-v1/CultureSearchRequest.serialization.schema.json
- docs/contracts/agent-v1/CultureSearchRequest.validation.schema.json
- docs/contracts/agent-v1/CultureSearchResponse.serialization.schema.json
- docs/contracts/agent-v1/CultureSearchResponse.validation.schema.json
- docs/contracts/agent-v1/EvaluationDataset.serialization.schema.json
- docs/contracts/agent-v1/EvaluationDataset.validation.schema.json
- docs/contracts/agent-v1/README.md
- docs/contracts/agent-v1/catalog-detail.json
- docs/contracts/agent-v1/catalog-item.json
- docs/contracts/agent-v1/catalog-search.json
- docs/contracts/agent-v1/clarification.json
- docs/contracts/agent-v1/completed.json
- docs/contracts/agent-v1/culture-documents.json
- docs/contracts/agent-v1/culture-search.json
- docs/contracts/agent-v1/decimal-wire-examples.json
- docs/contracts/agent-v1/detail-query.json
- docs/contracts/agent-v1/draft.json
- docs/contracts/agent-v1/invalid-examples.json
- docs/contracts/agent-v1/legacy-endpoints.json
- docs/contracts/agent-v1/request.json
- evaluation/seeds/v1/README.md
- evaluation/seeds/v1/catalog.json
- evaluation/seeds/v1/culture-corpus.json
- evaluation/seeds/v1/culture.json
- evaluation/seeds/v1/recommendation.json
- pyproject.toml
- tests/agent/test_contracts.py
- tests/agent/test_dataset.py
- tests/agent/test_legacy_snapshots.py
- uv.lock

Final git status:clean

## Spring complete file inventory (80 files)

Repository: /Users/yj/Desktop/Projects/janginharou/backend

- docs/contracts/agent-v1/AgentDraft.serialization.schema.json
- docs/contracts/agent-v1/AgentDraft.validation.schema.json
- docs/contracts/agent-v1/AgentRequest.serialization.schema.json
- docs/contracts/agent-v1/AgentRequest.validation.schema.json
- docs/contracts/agent-v1/AgentResponse.serialization.schema.json
- docs/contracts/agent-v1/AgentResponse.validation.schema.json
- docs/contracts/agent-v1/CatalogExperienceDetailsResponse.serialization.schema.json
- docs/contracts/agent-v1/CatalogExperienceDetailsResponse.validation.schema.json
- docs/contracts/agent-v1/CatalogExperienceResponse.serialization.schema.json
- docs/contracts/agent-v1/CatalogExperienceResponse.validation.schema.json
- docs/contracts/agent-v1/CatalogSearchRequest.serialization.schema.json
- docs/contracts/agent-v1/CatalogSearchRequest.validation.schema.json
- docs/contracts/agent-v1/CultureSearchRequest.serialization.schema.json
- docs/contracts/agent-v1/CultureSearchRequest.validation.schema.json
- docs/contracts/agent-v1/CultureSearchResponse.serialization.schema.json
- docs/contracts/agent-v1/CultureSearchResponse.validation.schema.json
- docs/contracts/agent-v1/EvaluationDataset.serialization.schema.json
- docs/contracts/agent-v1/EvaluationDataset.validation.schema.json
- docs/contracts/agent-v1/README.md
- docs/contracts/agent-v1/catalog-detail.json
- docs/contracts/agent-v1/catalog-item.json
- docs/contracts/agent-v1/catalog-search.json
- docs/contracts/agent-v1/clarification.json
- docs/contracts/agent-v1/completed.json
- docs/contracts/agent-v1/culture-documents.json
- docs/contracts/agent-v1/culture-search.json
- docs/contracts/agent-v1/decimal-wire-examples.json
- docs/contracts/agent-v1/detail-query.json
- docs/contracts/agent-v1/draft.json
- docs/contracts/agent-v1/invalid-examples.json
- docs/contracts/agent-v1/legacy-endpoints.json
- docs/contracts/agent-v1/request.json
- src/main/java/com/janginharou/domain/ai/dto/agent/AgentConstraints.java
- src/main/java/com/janginharou/domain/ai/dto/agent/AgentDraft.java
- src/main/java/com/janginharou/domain/ai/dto/agent/AgentRecommendation.java
- src/main/java/com/janginharou/domain/ai/dto/agent/AgentRequest.java
- src/main/java/com/janginharou/domain/ai/dto/agent/AgentResponse.java
- src/main/java/com/janginharou/domain/ai/dto/agent/AgentStatus.java
- src/main/java/com/janginharou/domain/ai/dto/agent/CatalogExperienceDetailsResponse.java
- src/main/java/com/janginharou/domain/ai/dto/agent/CatalogExperienceResponse.java
- src/main/java/com/janginharou/domain/ai/dto/agent/CatalogSearchRequest.java
- src/main/java/com/janginharou/domain/ai/dto/agent/CultureClaim.java
- src/main/java/com/janginharou/domain/ai/dto/agent/CultureDocument.java
- src/main/java/com/janginharou/domain/ai/dto/agent/CultureSearchRequest.java
- src/main/java/com/janginharou/domain/ai/dto/agent/CultureSearchResponse.java
- src/main/java/com/janginharou/domain/ai/dto/agent/RegionCode.java
- src/main/java/com/janginharou/domain/ai/dto/agent/StrictContract.java
- src/main/java/com/janginharou/domain/ai/dto/agent/WireValues.java
- src/test/java/com/janginharou/domain/ai/dto/agent/AgentContractTest.java
- src/test/resources/contracts/agent-v1/AgentDraft.serialization.schema.json
- src/test/resources/contracts/agent-v1/AgentDraft.validation.schema.json
- src/test/resources/contracts/agent-v1/AgentRequest.serialization.schema.json
- src/test/resources/contracts/agent-v1/AgentRequest.validation.schema.json
- src/test/resources/contracts/agent-v1/AgentResponse.serialization.schema.json
- src/test/resources/contracts/agent-v1/AgentResponse.validation.schema.json
- src/test/resources/contracts/agent-v1/CatalogExperienceDetailsResponse.serialization.schema.json
- src/test/resources/contracts/agent-v1/CatalogExperienceDetailsResponse.validation.schema.json
- src/test/resources/contracts/agent-v1/CatalogExperienceResponse.serialization.schema.json
- src/test/resources/contracts/agent-v1/CatalogExperienceResponse.validation.schema.json
- src/test/resources/contracts/agent-v1/CatalogSearchRequest.serialization.schema.json
- src/test/resources/contracts/agent-v1/CatalogSearchRequest.validation.schema.json
- src/test/resources/contracts/agent-v1/CultureSearchRequest.serialization.schema.json
- src/test/resources/contracts/agent-v1/CultureSearchRequest.validation.schema.json
- src/test/resources/contracts/agent-v1/CultureSearchResponse.serialization.schema.json
- src/test/resources/contracts/agent-v1/CultureSearchResponse.validation.schema.json
- src/test/resources/contracts/agent-v1/EvaluationDataset.serialization.schema.json
- src/test/resources/contracts/agent-v1/EvaluationDataset.validation.schema.json
- src/test/resources/contracts/agent-v1/catalog-detail.json
- src/test/resources/contracts/agent-v1/catalog-item.json
- src/test/resources/contracts/agent-v1/catalog-search.json
- src/test/resources/contracts/agent-v1/clarification.json
- src/test/resources/contracts/agent-v1/completed.json
- src/test/resources/contracts/agent-v1/culture-documents.json
- src/test/resources/contracts/agent-v1/culture-search.json
- src/test/resources/contracts/agent-v1/decimal-wire-examples.json
- src/test/resources/contracts/agent-v1/detail-query.json
- src/test/resources/contracts/agent-v1/draft.json
- src/test/resources/contracts/agent-v1/invalid-examples.json
- src/test/resources/contracts/agent-v1/legacy-endpoints.json
- src/test/resources/contracts/agent-v1/request.json

Final git status:clean
