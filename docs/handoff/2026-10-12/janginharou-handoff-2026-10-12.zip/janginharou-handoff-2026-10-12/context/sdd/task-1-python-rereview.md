# Task 1 Python scoped re-review

Spec verdict: **PASS for the original two P2 findings and the scoped fix**. Quality verdict: **PASS with one nonblocking P3 schema edge observation**. No new Critical/Important breakage was identified.

Target: `a8bd0ab78f21eeb34845f2e15166feaf4d06af43..8c22d88ced5d528938e6d0df7ca61c541ec92f75`. The supplied review package was read once, then current affected source, tests, README and implementation report were inspected. Scope is the original R1/R2 and new breakage in their fix, not another review of all Task 1 code. No application edits or commits were made.

## Original findings

| ID | Verdict | Evidence |
|---|---|---|
| R1: JSON numeric tokens lose precision before Decimal validation | **ADDRESSED** | `app/schemas/agent.py:12-44` parses raw numeric tokens with `json.loads(parse_float=Decimal)` and routes every `StrictContract.model_validate_json` through that parser. Dataset JSON uses that inherited method; referenced corpus JSON now uses `parse_contract_json` at `app/evaluation/dataset.py:95`. No float conversion occurs on those paths. The parser rejects nonfinite JSON constants. The README explicitly requires future HTTP routes to ingest raw body bytes rather than a pre-parsed float body; there is no new endpoint in this Task. |
| R2: published price scalar schema contradicts runtime bounds/grammar | **ADDRESSED** for the original P2 failures | `app/schemas/agent.py:62-86` defines an unsigned ordinary decimal string grammar, rejects signed/exponent/nonfinite strings, and publishes numeric `minimum: 0` plus `multipleOf: 0.01`. All affected checked-in validation schema price branches contain those constraints. Thus negative strings, three effective fractional digits and string exponent notation no longer have the original contradictory acceptance. Numeric exponent notation remains allowed, and numeric signed zero is normalized to unsigned output before serialization. A minor newline anchor corner is recorded separately below. |

## Test evidence inspected

The implementation report records `.venv/bin/python -m pytest tests -q` with output `128 passed in 1.82s`. It also records failing new tests before the fixes, including the original large/excess-precision numeric failures and the signed-zero serialization failure. The suite was not redundantly rerun during this review.

`tests/agent/test_contracts.py` contains explicit regressions for:

- Raw `9007199254740993.01` preserving the exact Decimal and string output.
- Raw `50000.000000000001` being rejected before rounding.
- String schema/runtime agreement for valid ordinary strings and negative, excessive-precision, exponent, plus-sign and nonfinite strings.
- Numeric schema validation with Decimal inputs and a Decimal-parsed schema, so binary float division does not contaminate the `multipleOf` assertions.
- Shared raw decimal wire examples, including numeric exponent, trailing zeros, boolean rejection and signed numeric zero normalization.

These checks directly protect the original failure mechanisms instead of merely repeating constructor/round-trip checks. Additional valid examples cover catalog details, culture search/documents and draft contracts. `jsonschema` is a dev dependency and its lockfile additions support the new schema checks. Existing runtime endpoint code is unaffected by the fix.

## New Critical/Important breakage

**None found** in the scoped diff. Exact numeric parsing is consistently used in both offline JSON ingestion paths, parser failures preserve a Pydantic ValidationError at the model JSON entry point, and zero normalization does not alter nonzero values.

## Nonblocking observation / outside the requested Important-or-higher bar

**P3:** the published string regex uses `$`, which matches immediately before a final line feed in JSON Schema regex matching, while `validate_price_form` uses `re.fullmatch`. Consequently the saved schema accepts `"50000\n"` and `"50000.01\n"`, but the runtime rejects both. Location: `app/schemas/agent.py:64,70` and the corresponding saved price patterns.

A focused probe with `Draft202012Validator` and `AgentRequest.model_validate` produced:

```text
'50000\n' schema-valid True
runtime rejected
'50000.01\n' schema-valid True
runtime rejected
```

This does not admit a bad monetary value into the runtime or reintroduce either original P2 failure, so it is a minor follow-up rather than a merge-blocking contract defect. If exact acceptance parity for every string is desired, use a JSON-Schema-compatible true end-of-input assertion and add a final-LF regression. No broader audit or test sweep was performed.

The scoped Python verdict does not certify Java parity, clean-checkout publication, new HTTP body integration or actual agent behavior; those remain the parent's separate validation scope.
