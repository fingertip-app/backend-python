# Task 1 Python review

Spec verdict: **changes required**. Code-quality verdict: **changes required**. Two P2 contract findings remain; no P0/P1 issue was identified in the reviewed scope.

Review target: `335720e63050765575da679094663bbc94925a84..a8bd0ab78f21eeb34845f2e15166feaf4d06af43`. Scope is Python schemas, exported JSON contracts, evaluation seeds/loader, preservation tests and documents. Java implementation, new endpoints, catalog runtime and agent execution are outside this review. Review performed against the supplied brief, evidence, diff and checked-out source. Product files were not changed and no commits were made.

## Accepted findings

### R1 — P2: preserve the JSON numeric token before Decimal validation

**Location:** `app/schemas/agent.py:28-35`, also `app/schemas/agent.py:60`; dataset JSON entry point `app/evaluation/dataset.py:89`.

The brief permits JSON numbers and requires exact Decimal handling with at most two fractional places. Declaring a Pydantic Decimal field does not preserve the original numeric token when `model_validate_json` parses it. The contract silently rounds the token before either precision validation or serialization:

```python
AgentConstraints.model_validate_json('{"maxPriceKrw":50000.000000000001}')
# accepted, maxPriceKrw == Decimal('50000'), wire price "50000"

AgentConstraints.model_validate_json('{"maxPriceKrw":9007199254740993.01}')
# accepted, maxPriceKrw == Decimal('9007199254740994')
```

The first input should be rejected for excessive fractional precision. The second input is a valid two-place amount, with no upper amount bound in the contract, but changes value. Supplying `Decimal('50000.000000000001')` directly correctly rejects it; that confirms the JSON parsing boundary loses information before the field validator can protect it. A normal `json.loads` followed by `model_validate` also loses the information because it produces a float.

**Impact:** accepted numeric requests or offline JSON datasets can alter a hard budget and differ from BigDecimal parsing. No new HTTP endpoint exists in this commit, so this is a contract/parser defect rather than a claim about a currently deployed agent route. Fix exact JSON parsing at every intended ingestion boundary before advertising numeric inputs as exact, and add tests using raw JSON numeric tokens. The existing test uses a preconstructed Python float `50000.01` and compares it with `Decimal(str(amount))`, so it cannot detect this failure.

**Spec:** fails the numeric-input precision/boundary requirement. **Quality:** missing protection at the actual parser boundary. **Disposition:** accepted; fix required.

### R2 — P2: make the published price validation schemas agree with the contract

**Location:** `docs/contracts/agent-v1/AgentRequest.validation.schema.json:17-25`. The same generated price definition appears in CatalogSearchRequest, AgentResponse, EvaluationDataset and both catalog response validation schemas.

The published validation schema gives the numeric branch only `minimum: 0` and `type: number`, so `50000.001` passes it despite the two-place rule. Its string pattern starts with `[+-]?`, so `"-0.01"` passes the schema even though the runtime rejects it with `greater_than_equal`. Conversely, the model accepts `"1e2"` as Decimal `1E+2`, while the schema rejects that string. This is already inconsistent with the shared invalid example `maxPriceKrw: "-0.01"`.

**Impact:** consumers using the documented common wire schema obtain different accepted inputs from Python/Spring model validation. This undermines the schema's purpose as a shared contract independently of R1's parsing loss. Correct/customize the exported scalar schema and specify one accepted decimal string grammar; verify the shared valid/invalid amount examples against both schema and runtime. Existing round-trip tests only validate models and never exercise the saved schema's acceptance rules.

**Spec:** common validation contract is inconsistent. **Quality:** exported contract and tests allow contradictory sources of truth. **Disposition:** accepted; fix required.

## Reviewed behavior without additional findings

- All target changes are additions; existing runtime endpoint/router/provider files are unchanged. Preservation tests pin explain/recommendation success, recommendation provider failure, missing/invalid internal key, and legacy request ranges.
- Strict unknown fields, integer ranges/coercion restrictions, region/locale enums, search term trimming/count/ranges, response ID matching/uniqueness and unsupported-condition status rules are present in the Python models. Examples agree with those runtime checks for their supplied values.
- Each seed contains 20 cases, four required categories with five cases each, and ten cases in each split. The six existing culture smoke queries are included. Culture topic paraphrases share group/split; recommendation cases vary hard conditions and are documented as independent groups. No definite current seed split leak was identified.
- The twelve catalog fixture IDs and required price/region/capacity/active/address variations are present. The listed allowed/forbidden IDs agree with the relevant topic and fixed active/region/price/capacity conditions. Empty/inactive/conflict/unsupported cases have the appropriate expected status.
- Corpus hashes and references are checked by the loader, including sibling-file restriction, duplicate fixture IDs, duplicate case IDs, group split conflicts, ID overlap and mode/source separation. Current dataset and corpus provenance both honestly say synthetic and `humanReviewed=false`; documentation explicitly excludes real heritage/AI-quality claims. A real snapshot remains a Task 6 prerequisite, consistent with the brief's scope correction.
- Natural-language conflict detection, server-rendered facts and factuality evaluation are correctly documented as future runtime work; schema-only tests are not presented as verifying those behaviors.

## Validation evidence and limits

The supplied evidence reports 47 new tests failing before implementation and the full suite passing with 112 tests afterward. Those reported test commands were not rerun. Focused, previously uncovered parser/schema probes were run with the repository `.venv/bin/python`; their exact outcomes are recorded above. Exported-schema price branches were inspected directly and their regex was exercised. No external services, live model, database or Java counterpart was evaluated. Clean-checkout validation remains pending parent publication, as stated in the supplied evidence.
